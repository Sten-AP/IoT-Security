# Reflectieverslag

Sten Hulsbergen

## Reflectie

Al een lange tijd heb ik thuis een broker staan op een Raspberry pi dat Home Assistant host. Op dit moment zijn het maar twee Pico W's die een temperatuur en vochtigheid sturen. Maar nu met de kennis over een scanner voor de netwerken, het verbinden van netwerken en de poorten scannen is het toch best eng dat iemand zo aan deze data zou kunnen komen, zeker als er meerdere en belangrijker apparatuur aan zou hangen.

In het algemeen ging het project vrij soepel, dit komt omdat de labo's best goed gingen en daardoor ook het implementeren van een encryptie niet meer zo moeilijk was. Daarnaast hebben we in het algemeen al veel gewerkt met MQTT en ik persoonlijk ook met veel OOP.

In de toekomst zou ik geen beveiligings-apparatuur aansluiten aan een MQTT-broker dit is veel te makkelijk uit te lezen en zou een groot veiligheidsrisico kunnen zijn. Dit zal ik zeker vermijden waar mogelijk.
